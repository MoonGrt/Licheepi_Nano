#ifndef _ESP_PATH_H_
#define _ESP_PATH_H_
#define FWPATH "/lib/firmware"
//module_param_string(fwpath, fwpath, sizeof(fwpath), 0644);

#endif				/* _ESP_PATH_H_ */
